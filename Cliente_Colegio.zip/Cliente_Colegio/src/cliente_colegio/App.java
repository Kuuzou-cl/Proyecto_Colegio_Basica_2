/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente_colegio;

import java.text.ParseException;
import org.orm.PersistentException;

/**
 * Clase que inicia el programa, y genera la ventana principal
 * @author kuuzou
 */
public class App {
    
    /**
     * Metodo que inicia el programa y genera la ventana principal
     * @param args 
     */
    public static void main(String []args) throws ParseException, PersistentException{
        Proyecto ventana=new Proyecto();
        ventana.setVisible(true);
    }
}
